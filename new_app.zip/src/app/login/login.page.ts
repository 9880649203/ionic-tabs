import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective,FormGroup, NgForm, Validators } from '@angular/forms';
import {NavController, MenuController,} from '@ionic/angular';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  UserDetails={passWord:'',userName:''};

  constructor(private navcntrl:NavController) { }

  ngOnInit() {
 this.loginForm = new FormGroup({
   userName :new FormControl("",[]),
   passWord:new FormControl("",[])
   });
  }

  submitForm(){
    console.log("values",this.loginForm.value)
  }

  
 
}